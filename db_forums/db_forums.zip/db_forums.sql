-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2017 at 08:27 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_forums`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Cars'),
(2, 'Movies'),
(3, 'Anime'),
(4, 'Bold'),
(5, 'Programming'),
(6, 'Designs'),
(7, 'Soldiers'),
(8, 'Dota'),
(9, 'IT'),
(10, 'CCIS'),
(11, 'undefined'),
(12, 'TANGINAMO CIS'),
(13, 'ty'),
(14, ''),
(15, 'LOVE YOU SIR');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `author` varchar(80) NOT NULL,
  `category_name` varchar(80) NOT NULL,
  `title` varchar(80) NOT NULL,
  `content` text NOT NULL,
  `pdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `author`, `category_name`, `title`, `content`, `pdate`) VALUES
(2, 'jshrmcy', 'IT', 'WAG MAG IT', 'TANGINA PURO PROGRAMMIING NAKAKBWISET ANG HIGPIT PA', '2017-08-18'),
(3, 'jshrmcy', 'IT', 'MIDTERM NGAYON', 'AT HINDI AKO NAKAPAGTAKE PUTAANGINANG BUHAY TO AYOKO BUMAGSAK', '2017-08-18'),
(5, 'jshrmcy', 'Designs', 'FRONT END', 'NAKAKAPUTA MAG FRONT END', '2017-08-18'),
(6, 'jshrmcy', 'IT', 'kagaguhan', 'TANGINA DI AKO NAKAPAG MIDTERM', '2017-08-18'),
(7, 'undefined', 'undefined', 'undefined', 'undefined', '2017-08-18'),
(8, 'undefined', 'undefined', 'undefined', 'undefined', '2017-08-18'),
(9, 'undefined', 'IT', 'ASDHASUDHUASHD', 'undefined', '2017-08-18'),
(12, 'rae@macaya.com', 'IT', '', '', '2017-08-18'),
(13, 'rae@macaya.com', 'IT', '', '', '2017-08-18'),
(14, 'rae@macaya.com', 'IT', '', '', '2017-08-18'),
(15, 'rae@macaya.com', 'IT', '', '', '2017-08-18'),
(16, 'rae@macaya.com', 'IT', '', '', '2017-08-18'),
(17, 'rae@macaya.com', 'Cars', 'Ferrari', 'Sobrang Bilis tol. POWER!', '2017-08-18'),
(20, 'crisaldo.22@gmail.com', 'IT', 'ANG KYOT NI CRIS', 'MAHAL KO SYA <3', '2017-08-18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `birthdate` date NOT NULL,
  `user_type` enum('user','admin') DEFAULT NULL,
  `password` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `birthdate`, `user_type`, `password`) VALUES
(1, 'jshrmcy', 'macaya737@gmail.com', '1998-12-22', 'user', '12345'),
(2, 'rae', 'rae@macaya.com', '1999-05-05', 'user', '1234567'),
(3, 'undefined', 'crisaldo.22@gmail.com', '1999-02-05', '', 'crissy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
